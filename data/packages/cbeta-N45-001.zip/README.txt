UTF-8 / ZIP (DEFLATE) / BagIt 1.0 / SHA-256
Original files are authoritative. Reading text is derived and may lose markup.
See data/source.json and data/notices/ for source versions and terms.
Extract with any ZIP utility. No website, account, database or API is required.
